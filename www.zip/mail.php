<?php
$phone = $_POST['phone'];
if(empty($phone)) {
?>
<?
}else {
	
$email2="test22@mail.ru"; // ----------------------------------------- почта, куда отправляем письмо
$headers  =  'MIME-Version: 1.0' . "\r\n";
	$headers .=  'Content-type: text/html; charset=UTF-8' . "\r\n";
	$headers .=  'To: <'.$email2.'>, '."\r\n";
	$headers .=  'From: <site.ru>' . "\r\n"; // ---------------------- адрес отправителя, это заголовок письма, менять не обязательно
$subject2    = "Новая заявка с сайта"; // ----------------------------------------- заголовок
$message2    = "
<br>Имя: ".$_POST['name']."
<br>Телефон: ".$_POST['phone']."
<br>E-mail: ".$_POST['mail']."
<br>Способ связи: ".$_POST['button']."
<br>
<br>Какой тип дома Вам необходим: ".$_POST['otvet1']."
<br>Какую кровлю Вы хотите использовать: ".$_POST['otvet2']."
<br>Когда Вы планируете начать строительство: ".$_POST['otvet3']."
<br>акая допкомплектация дома Вам необходима: ".$_POST['otvet4']."
<br>В каком регионе Вы хотите построить дом: ".$_POST['otvet5']."
<br>
<br>IP-адрес посетителя: ".@$_SERVER['REMOTE_ADDR']."
<br>Время заказа: ".date('Y-m-d H:i:s')."
";
$mail=mail($email2, $subject2, $message2, $headers);
if($mail==true){
?>
<?
}else{
    echo "no";
}
}
?>
