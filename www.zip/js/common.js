$(function () {
    jQuery(document).ready(function ($) {


        jQuery(document).on('click', ".mob-menu", function () {
            jQuery(".menu").slideDown(500);
        });
        jQuery(document).on('click', ".close-mob", function () {
            jQuery(".menu").slideUp(500);
            jQuery(".mob-menu").show(500);
        });


        jQuery(document).on('click', ".form .buttons button", function (e) {
            e.preventDefault()
            jQuery(".form .buttons button").removeClass("active");
            jQuery(this).addClass("active");
            $('[name="button"]').val(jQuery(this).children("span").text())
            if ($(this).children("span").text() == "E-mail"){
                $(this).parents("form").find("[name='phone']").prop("hidden", true)
                $(this).parents("form").find("[name='mail']").prop("hidden", false)
            }
            else if ($(this).children("span").text() == "WhatsApp") {
                $(this).parents("form").find("[name='phone']").prop("hidden", false)
                $(this).parents("form").find("[name='phone']").attr("placeholder", "Введите номер WhatsApp")
                $(this).parents("form").find("[name='mail']").prop("hidden", true)
            }
            else if ($(this).children("span").text() == "Telegram") {
                $(this).parents("form").find("[name='phone']").prop("hidden", false)
                $(this).parents("form").find("[name='phone']").attr("placeholder", "Введите свой Telegram")
                $(this).parents("form").find("[name='mail']").prop("hidden", true)
            }
            else {
                $(this).parents("form").find("[name='phone']").prop("hidden", false)
                $(this).parents("form").find("[name='phone']").attr("placeholder", "Введите свой телефон")
                $(this).parents("form").find("[name='mail']").prop("hidden", true)
            }
        });


        [].forEach.call(document.querySelectorAll('img[data-src]'), function (img) {
            img.setAttribute('src', img.getAttribute('data-src'));
            img.onload = function () {
                img.removeAttribute('data-src');
            };
        });


        jQuery(document).on('click', ".vopros.item-1 .otvet .item", function (e) {
            $(".item-1 .otvet .item").removeClass("active")
            $(this).addClass("active")
            $("[name='otvet1']").attr('value',$(this).find(".desk").text())
            console.log($(this).find(".desk").text());
            $(".vopros .otvet .item").removeClass("error")
        });
        jQuery(document).on('click', ".vopros.item-2 .otvet .item", function (e) {
            $(".item-2 .otvet .item").removeClass("active")
            $(this).addClass("active")
            $("[name='otvet2']").attr('value',$(this).find(".desk").text())
            $(".vopros .otvet .item").removeClass("error")
        });
        jQuery(document).on('click', ".vopros.item-3 .otvet .item", function (e) {
            $(".item-3 .otvet .item").removeClass("active")
            $(this).addClass("active")
            $("[name='otvet3']").attr('value',$(this).find(".desk").text())
            $(".vopros .otvet .item").removeClass("error")
        });
        jQuery(document).on('click', ".vopros.item-4 .otvet .item", function (e) {
            
            $(this).addClass("active")
        
            $("[name='otvet-4']").val(" ")
            var a = ""
            $( '.vopros.item-4 .otvet .item.active' ).each(function( index ) {
                
                a = a + $(this).find(".desk").text()
            });
            $("[name='otvet4']").attr('value',a)
           
            $(".vopros .otvet .item").removeClass("error")
        });
        jQuery(document).on('click', ".vopros.item-5 .otvet .item", function (e) {
            $(".item-5 .otvet .item").removeClass("active")
            $(this).addClass("active")
            $("[name='otvet5']").attr('value',$(this).find(".desk").text())
            $(".vopros .otvet .item").removeClass("error")
        });


        jQuery(document).on('click', ".vopros.item-1 .btn_red", function (e) {
            e.preventDefault()
            var ea = $(this).parents(".vopros").find(".otvet .item");
            $(".vopros .otvet .item").removeClass("error")
            ea.each(function (index) {
                if ($(this).hasClass("active")) {
                    $(".vopros").hide()
                    $(".vopros.item-2").show()
                    $(this).addClass("active")
                    $("[name='otvet-1']").val($(this).find(".desk").text())

                    $(".indicator .span-1").addClass("active")
                    $(".vasha span").text("1%")

                } else {
                    $(".vopros.item-1 .otvet .item").addClass("error")
                }
            });
        });


        jQuery(document).on('click', ".vopros.item-2 .btn_red", function (e) {
            e.preventDefault()
            var ea = $(this).parents(".vopros").find(".otvet .item");
            $(".vopros .otvet .item").removeClass("error")
            ea.each(function (index) {
                if ($(this).hasClass("active")) {
                    $(".vopros").hide()
                    $(".vopros.item-3").show()
                    $(this).addClass("active")
                    $("[name='otvet-2']").val($(this).find(".desk").text())
                    $(".indicator .span-2").addClass("active")
                    $(".vasha span").text("2%")
                } else {
                    $(".vopros.item-2 .otvet .item").addClass("error")
                }
            });
        });

        jQuery(document).on('click', ".vopros.item-3 .btn_red", function (e) {
            e.preventDefault()
            var ea = $(this).parents(".vopros").find(".otvet .item");
            $(".vopros .otvet .item").removeClass("error")
            ea.each(function (index) {
                if ($(this).hasClass("active")) {
                    $(".vopros").hide()
                    $(".vopros.item-4").show()
                    $(this).addClass("active")
                    $("[name='otvet-3']").val($(this).find(".desk").text())
                    $(".indicator .span-3").addClass("active")
                    $(".vasha span").text("3%")
                } else {
                    $(".vopros.item-3 .otvet .item").addClass("error")
                }
            });
        });

        jQuery(document).on('click', ".vopros.item-4 .btn_red", function (e) {
            e.preventDefault()
            var ea = $(this).parents(".vopros").find(".otvet .item");
            $(".vopros .otvet .item").removeClass("error")
            ea.each(function (index) {
                if ($(this).hasClass("active")) {
                    $(".vopros").hide()
                    $(".vopros.item-5").show()
                    $(this).addClass("active")
                    $(".indicator .span-4").addClass("active")
                    $(".vasha span").text("4%")
                } else {
                    $(".vopros.item-4 .otvet .item").addClass("error")
                }
            });
        });

        jQuery(document).on('click', ".vopros.item-5 .btn_red", function (e) {
            e.preventDefault()
            var ea = $(this).parents(".vopros").find(".otvet .item");
            $(".vopros .otvet .item").removeClass("error")
            ea.each(function (index) {
                if ($(this).hasClass("active")) {
                    $("[name='otvet-5']").val($(this).find(".desk").text());
                    $(".modal").modal("hide")
                    $("#otvet").modal("show")
                    $(".vopros.item-1").show()
                    $(".vopros.item-5").hide()
                    $(".otvet .item").removeClass("active")

                    $(".indicator .span-5").addClass("active")
                    $(".vasha span").text("5%")
                } else {
                    $(".vopros.item-5 .otvet .item").addClass("error")
                }
            });
        });


        if ($(window).width() <= 991) {

        }


        $(".send-form").submit(function(event) { 
            event.preventDefault();
            var th = $(this);
            console.log(th);
            $.ajax({
              url:     "mail.php", 
              type:     "POST", 
              data: th.serialize(),  
              success: function(response) { 
                console.log(response);
                th.trigger("reset");
                $(".modal").modal("hide");
                $('#senk').modal('show');
                 setTimeout(function(){                   
                    $('#senk').modal('hide');
              }, 3000);
              },
              error: function(response) {
                console.log(response); 
              }
             });
          });





        $('form label.checkbox input[type="checkbox"]').click(function(){

            if ($(this).is(':checked')){
                $(this).parents("form").find("[type='submit']").prop("disabled", false)
            } else {
                $(this).parents("form").find("[type='submit']").prop("disabled", true)
            }

        });

        $( 'form label.checkbox input[type="checkbox"]' ).each(function( index ) {
            $(this).prop("checked", true)
        });









        $('header .bottom .flex').slick({
            infinite: false,
            arrows: true,
            focusOnSelect: true,
            dots: false,
            slidesToShow: 1,
            slidesToScroll: 1,
            prevArrow: '<button type="button" class="slick-prev"></button>',
            nextArrow: '<button type="button" class="slick-next"></button>',
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });

        /*$(window).on("load",function(){
            $(".content").mCustomScrollbar();
        });*/


        $('[name="phone"]').mask("+7 (999) 999-99-99");

        $('a[href^="#"].yak').click(function () {
            elementClick = $(this).attr("href");
            // elementClick = elementClick.substr(1);
            destination = $(elementClick).offset().top;
            $('body,html').animate({scrollTop: destination}, 1100);
            return false;
        });


    });
});
